package Math::BigFloat::BareSubclass;
use base 'Math::BigFloat';
1;
