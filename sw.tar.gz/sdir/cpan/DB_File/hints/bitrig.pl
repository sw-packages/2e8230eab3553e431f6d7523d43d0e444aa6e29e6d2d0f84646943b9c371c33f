no strict 'vars';
$self->{LIBS} = [''];
